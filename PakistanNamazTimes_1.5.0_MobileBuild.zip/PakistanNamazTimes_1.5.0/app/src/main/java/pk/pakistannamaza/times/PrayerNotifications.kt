package pk.pakistannamaza.times

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.DateComponents
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import java.util.Calendar
import java.util.TimeZone

private const val CHANNEL_ID = "prayer_times"
private const val EXTRA_PRAYER_EN = "prayer_en"
private const val EXTRA_PRAYER_UR = "prayer_ur"
private const val EXTRA_REQUEST_ID = "request_id"

fun createPrayerNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Prayer time reminders",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Simple reminders for daily prayer times"
        }
        context.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }
}

/**
 * Schedules prayer reminders for the next seven days.
 * Android may require the user to allow exact alarms in system settings.
 */
fun schedulePrayerReminders(context: Context) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
        !alarmManager.canScheduleExactAlarms()
    ) {
        return
    }

    val zone = TimeZone.getTimeZone("Asia/Karachi")
    val now = Calendar.getInstance(zone)
    val coordinates = Coordinates(24.8607, 67.0011)

    val prayerList = listOf(
        Triple("Fajr", "فجر", 1),
        Triple("Dhuhr", "ظہر", 2),
        Triple("Asr", "عصر", 3),
        Triple("Maghrib", "مغرب", 4),
        Triple("Isha", "عشاء", 5)
    )

    for (dayOffset in 0..7) {
        val dateCalendar = Calendar.getInstance(zone).apply {
            timeInMillis = now.timeInMillis
            add(Calendar.DAY_OF_YEAR, dayOffset)
        }
        val date = DateComponents.from(dateCalendar.time)
        val params = CalculationMethod.KARACHI.parameters
        params.madhab = Madhab.HANAFI
        val times = PrayerTimes(coordinates, date, params)
        val timesByCode = listOf(
            times.fajr, times.dhuhr, times.asr, times.maghrib, times.isha
        )

        prayerList.forEachIndexed { index, prayer ->
            val triggerAt = timesByCode[index].time
            if (triggerAt > System.currentTimeMillis()) {
                val requestId = dayOffset * 10 + prayer.third
                val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                    putExtra(EXTRA_PRAYER_EN, prayer.first)
                    putExtra(EXTRA_PRAYER_UR, prayer.second)
                    putExtra(EXTRA_REQUEST_ID, requestId)
                }
                val pending = PendingIntent.getBroadcast(
                    context,
                    requestId,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAt,
                    pending
                )
            }
        }
    }
}

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val english = intent.getStringExtra(EXTRA_PRAYER_EN) ?: "Prayer"
        val urdu = intent.getStringExtra(EXTRA_PRAYER_UR) ?: "نماز"
        val requestId = intent.getIntExtra(EXTRA_REQUEST_ID, 0)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Pakistan Namaz Times")
            .setContentText("$english time / $urdu کا وقت")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(requestId, notification)
        } catch (_: SecurityException) {
            // Notification permission may have been denied by the user.
        }

        // Refresh the rolling schedule after an alarm fires.
        schedulePrayerReminders(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED
        ) {
            schedulePrayerReminders(context)
        }
    }
}
