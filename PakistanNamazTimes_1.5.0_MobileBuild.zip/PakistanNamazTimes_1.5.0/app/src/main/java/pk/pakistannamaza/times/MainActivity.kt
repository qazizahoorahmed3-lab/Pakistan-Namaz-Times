package pk.pakistannamaza.times

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.DateComponents
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) schedulePrayerReminders(this)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createPrayerNotificationChannel(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestExactAlarmAccessIfNeeded()
        }

        setContent { PakistanNamazTimesApp() }
    }

    private fun requestExactAlarmAccessIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!manager.canScheduleExactAlarms()) {
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (_: Exception) { }
                return
            }
        }
        schedulePrayerReminders(this)
    }
}

private data class PrayerRow(val nameEn: String, val nameUr: String, val time: String)

private fun getKarachiPrayerTimes(): List<PrayerRow> {
    val zone = TimeZone.getTimeZone("Asia/Karachi")
    val date = DateComponents.from(Date())
    val coordinates = Coordinates(24.8607, 67.0011)
    val params = CalculationMethod.KARACHI.parameters
    params.madhab = Madhab.HANAFI
    val prayerTimes = PrayerTimes(coordinates, date, params)
    val formatter = SimpleDateFormat("hh:mm a", Locale.getDefault()).apply {
        timeZone = zone
    }

    return listOf(
        PrayerRow("Fajr", "فجر", formatter.format(prayerTimes.fajr)),
        PrayerRow("Sunrise", "طلوعِ آفتاب", formatter.format(prayerTimes.sunrise)),
        PrayerRow("Dhuhr", "ظہر", formatter.format(prayerTimes.dhuhr)),
        PrayerRow("Asr", "عصر", formatter.format(prayerTimes.asr)),
        PrayerRow("Maghrib", "مغرب", formatter.format(prayerTimes.maghrib)),
        PrayerRow("Isha", "عشاء", formatter.format(prayerTimes.isha))
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PakistanNamazTimesApp() {
    var urdu by remember { mutableStateOf(false) }
    val prayers = remember { getKarachiPrayerTimes() }
    val today = remember {
        SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(if (urdu) "پاکستان نماز ٹائمز" else "Pakistan Namaz Times")
                    },
                    actions = {
                        TextButton(onClick = { urdu = !urdu }) {
                            Text(if (urdu) "English" else "اردو")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text(
                                if (urdu) "کراچی، پاکستان" else "Karachi, Pakistan",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(today, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                if (urdu) "حساب: کراچی | عصر: حنفی"
                                else "Calculation: Karachi | Asr: Hanafi",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                item {
                    Text(
                        if (urdu) "آج کے نماز کے اوقات" else "Today's Prayer Times",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(prayers) { prayer ->
                    Card {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (urdu) prayer.nameUr else prayer.nameEn,
                                style = MaterialTheme.typography.titleMedium)
                            Text(prayer.time, style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    Text(
                        if (urdu)
                            "نماز کے اوقات مقامی مسجد کے مستند اوقات سے ضرور ملائیں۔"
                        else
                            "Please verify prayer times with a trusted local mosque timetable.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
