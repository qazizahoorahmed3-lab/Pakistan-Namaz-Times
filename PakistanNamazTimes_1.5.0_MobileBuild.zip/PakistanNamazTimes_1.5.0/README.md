# Pakistan Namaz Times — Version 1.5.0 mobile-testing starter

## Device target
Test device supplied by user: TECNO KL5, Android 14.

## Included in this iteration
- Kotlin + Jetpack Compose Android app
- Karachi coordinates and Karachi calculation method
- Hanafi Asr setting
- Urdu / English screen toggle
- Prayer notification channel
- Android 13+ notification permission request
- Exact-alarm access check for Android 12+
- Prayer reminders scheduled for the next eight calendar days
- Rescheduling after device reboot and exact-alarm permission changes
- GitHub Actions workflow to build a debug APK in the cloud

## Build without Android Studio (GitHub Actions)
1. Sign in to GitHub in your phone browser and create a new empty repository.
2. Upload the contents of this project folder to the repository (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build Pakistan Namaz Times APK** and tap **Run workflow**.
5. When the workflow completes, open the run and download the `PakistanNamazTimes-debug-apk` artifact.
6. Extract the downloaded artifact and install the APK on the TECNO KL5. Android may ask you to allow installation from your browser or file manager; only enable it for the app you used to download the APK, then turn it off again afterward.

## Important
This is a development build, not a verified release. The project has not been compiled or tested on a physical device in this environment. Confirm Gradle build success in GitHub Actions before installing. The alarm schedule and notification behavior need real-device testing; some TECNO battery-management settings may delay background alarms. Exact alarm permission and notification permission are user-controlled. Do not disable general phone security protections.

Before public release, verify prayer times against a trusted Karachi mosque timetable and test daylight/date boundaries, reboot behavior, denied permissions and battery restrictions. Qibla, Hijri calendar, city selection, full localization, privacy policy, release signing and Play Store listing remain future tasks.
